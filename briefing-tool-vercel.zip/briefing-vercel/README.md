# Integrative Briefing Tool

An AI-powered briefing tool based on the frameworks from *Managing the Brief for Better Design* (Blyth & Worthington) and the forthcoming *Integrative Briefing* book.

## Deploy to Vercel (5 minutes)

### 1. Create a GitHub repository

1. Go to [github.com](https://github.com) and create a new repository (e.g. `briefing-tool`)
2. Upload all files from this folder — drag and drop works fine in the GitHub interface
3. Make sure the folder structure is preserved:
   ```
   api/
     chat.js
   public/
     index.html
   package.json
   vercel.json
   README.md
   ```

### 2. Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) and sign in (free account works)
2. Click **Add New → Project**
3. Import your GitHub repository
4. Leave all build settings as defaults — Vercel will detect the structure automatically
5. Click **Deploy**

### 3. Add your Anthropic API key

1. Once deployed, go to your project in the Vercel dashboard
2. Click **Settings → Environment Variables**
3. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from [console.anthropic.com](https://console.anthropic.com)
4. Click **Save**
5. Go to **Deployments** and click **Redeploy** (top right) to apply the key

### 4. Share the URL

Vercel gives you a URL like `https://briefing-tool-abc123.vercel.app` — share this with anyone. No login, no API key required from users.

---

## How it works

- `public/index.html` — the full tool UI (HTML/CSS/JS, no build step needed)
- `api/chat.js` — a serverless function that receives requests from the UI and forwards them to the Anthropic API using the key stored in Vercel's environment variables
- The API key never appears in the browser — all requests go through the serverless function

## Custom domain (optional)

In Vercel → Settings → Domains, you can add your own domain (e.g. `briefing.yoursite.com`).

## Costs

- Vercel free tier is sufficient for moderate use
- Anthropic API costs approximately $0.003–0.015 per conversation depending on length
- You may want to add rate limiting to `api/chat.js` if you expect heavy usage
